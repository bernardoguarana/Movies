import star from '../assets/star.svg';

export function List() {
    return (
        <div className="max-w-[1140px] mx-auto py-14">
            <div className="flex">

                <div className="max-w-[360px] h-[200px]  relative">
                    <img className='rounded-lg' src="https://image.tmdb.org/t/p/w400/cnqwv5Uz3UW5f086IWbQKr3ksJr.jpg" />

                    <div className='absolute bottom-3 left-3'>
                        <h2 className='text-2xl font-bold'>Aquaman 2: O reino Perdido</h2>
                        <h3 className='font-bold'>Ano: 2023</h3>
                        <div className='flex gap-x-3' >
                            <img src={star} alt="" />
                            <span className='text-rm-yellow-200'>7.0</span>
                        </div>
                    </div>

                </div>

            </div>

        </div>
    )
}