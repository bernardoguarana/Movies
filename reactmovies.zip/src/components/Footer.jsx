export function Footer(){
    return(
        <footer className="bg-rm-blue-900 text-center py-4 fixed bottom-0 w-full">
            <p>Projeto desenvolvido por: BG Sites</p>
        </footer>
    )
}