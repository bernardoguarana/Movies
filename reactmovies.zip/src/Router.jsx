import { Route, Routes } from "react-router-dom";
import { Home } from "./pages/Home";
import { Series } from "./pages/Series";
import { Filmes } from "./pages/Filmes";



export function Router() {
    return (
        <Routes>

            <Route path="/" element={<Home/>}  />
            <Route path="/filmes" element={<Filmes/>}  />
            <Route path="/series" element={<Series/>}  />


        </Routes>
    )
}